# AI 블로그 공장 MVP

키워드 → 한국어 블로그 초안 → 썸네일 배경 → 저장/수정 → Blogger 전송을 한 화면에서 처리하는 개인용 MVP입니다.

## 현재 포함된 기능

- 키워드, 글 유형, 분량, 실제 경험 입력
- OpenAI API를 이용한 제목/메타설명/HTML 본문/해시태그 생성
- 이미지 API를 이용한 썸네일 배경 생성
- SQLite 로컬 저장
- 글 수정 및 미리보기
- Blogger API 임시저장/즉시발행
- API 키가 없을 때 데모 초안 생성

## 설치

Python 3.11 이상 권장

```bash
python -m venv .venv
# Windows
.venv\Scripts\activate
# macOS/Linux
source .venv/bin/activate

pip install -r requirements.txt
cp .env.example .env
```

`.env`에 값을 넣습니다. Flask는 환경변수를 자동으로 읽지 않으므로 다음 중 하나를 사용하세요.

```bash
pip install python-dotenv
flask --app app run --debug
```

또는 운영체제 환경변수로 등록한 뒤:

```bash
python app.py
```

브라우저에서 `http://localhost:5000` 접속.

## Blogger 연결

1. Google Cloud Console에서 프로젝트 생성
2. Blogger API v3 활성화
3. OAuth 2.0 동의 화면과 클라이언트 설정
4. `https://www.googleapis.com/auth/blogger` 범위로 액세스 토큰 발급
5. 블로그 ID와 토큰을 `.env`의 `BLOGGER_BLOG_ID`, `BLOGGER_ACCESS_TOKEN`에 입력

현재 MVP는 액세스 토큰을 직접 넣는 방식입니다. 토큰이 만료되면 새로 넣어야 합니다. 정식 서비스에서는 Google 로그인과 refresh token 저장 기능을 추가해야 합니다.

## 중요한 운영 원칙

- AI 글은 바로 발행하지 말고 사실, 가격, 운영시간을 확인하세요.
- 직접 경험, 사진, 비교 기준을 추가하세요.
- 의료, 보험, 금융, 법률 분야는 전문가 검수 없이 자동 발행하지 마세요.
- 공개 서버에 올릴 때는 로그인, CSRF 방어, 비밀키 암호화, 백업을 추가하세요.

## 다음 버전 권장 기능

- Google OAuth 자동 로그인 및 토큰 갱신
- 예약 발행
- 키워드 목록 일괄 생성
- 제목 선택 화면
- 썸네일 위 한글 문구 합성
- 검색 성과 및 애드센스 통계 대시보드
- 사용자별 계정과 사용량 제한

# V2: 인터넷 배포와 Google 자동 연결

이 버전은 다음이 추가되었습니다.

- Google OAuth 연결 버튼
- Blogger 권한 토큰 자동 갱신
- 연결된 첫 번째 Blogger 블로그 자동 선택
- Render 배포용 `render.yaml`, `Procfile`, Gunicorn
- 서버 재배포 후에도 글과 토큰을 유지할 수 있는 `DATA_DIR`
- Blogger 글이 두 번 올라갈 수 있던 중복 호출 수정

## 로컬 테스트

Google Cloud Console의 승인된 리디렉션 URI에 아래 주소를 추가합니다.

```
http://localhost:5000/google/callback
```

`.env`에는 아래 값을 입력합니다.

```
GOOGLE_CLIENT_ID=...
GOOGLE_CLIENT_SECRET=...
GOOGLE_REDIRECT_URI=http://localhost:5000/google/callback
```

## Render 배포

1. 이 폴더를 GitHub 저장소에 업로드합니다.
2. Render에서 Blueprint 또는 Web Service로 저장소를 연결합니다.
3. 환경변수 `OPENAI_API_KEY`, `GOOGLE_CLIENT_ID`, `GOOGLE_CLIENT_SECRET`을 입력합니다.
4. 첫 배포 후 생긴 사이트 주소가 `https://내사이트.onrender.com`이라면 Google Cloud Console에 다음 리디렉션 URI를 등록합니다.

```
https://내사이트.onrender.com/google/callback
```

5. Render의 `GOOGLE_REDIRECT_URI`에도 같은 주소를 입력하고 재배포합니다.
6. 사이트에서 `Google 계정 연결`을 누릅니다.

## 주의

- `render.yaml`은 영구 디스크를 사용하도록 작성했습니다. Render 요금제에 따라 디스크 사용 가능 여부가 달라질 수 있습니다.
- 여러 Blogger 블로그가 있다면 현재는 첫 번째 블로그를 자동 선택합니다.
- 공개 서비스로 판매하려면 사용자별 로그인, 데이터 분리, 이용량 과금, 개인정보처리방침이 추가로 필요합니다.
