import base64
import json
import os
import sqlite3
from datetime import datetime
from pathlib import Path
from typing import Any

import requests
from flask import Flask, flash, redirect, render_template, request, send_from_directory, session, url_for
from markupsafe import Markup
from google.auth.transport.requests import Request as GoogleAuthRequest
from google.oauth2.credentials import Credentials
from google_auth_oauthlib.flow import Flow

BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = Path(os.getenv("DATA_DIR", str(BASE_DIR / "data")))
THUMB_DIR = DATA_DIR / "thumbnails"
DB_PATH = DATA_DIR / "articles.db"
THUMB_DIR.mkdir(parents=True, exist_ok=True)

app = Flask(__name__)
app.secret_key = os.getenv("FLASK_SECRET_KEY", "change-me-before-public-use")
app.config.update(SESSION_COOKIE_HTTPONLY=True, SESSION_COOKIE_SAMESITE="Lax", SESSION_COOKIE_SECURE=os.getenv("SESSION_COOKIE_SECURE", "false").lower() == "true")
BLOGGER_SCOPE = "https://www.googleapis.com/auth/blogger"


def db() -> sqlite3.Connection:
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init_db() -> None:
    with db() as conn:
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS articles (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                keyword TEXT NOT NULL,
                title TEXT NOT NULL,
                meta_description TEXT,
                content_html TEXT NOT NULL,
                hashtags TEXT,
                thumbnail_path TEXT,
                status TEXT NOT NULL DEFAULT 'saved',
                blogger_post_id TEXT,
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL
            )
            """
        )
        conn.execute(
            """CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT NOT NULL)"""
        )


def get_setting(key: str, default: str = "") -> str:
    with db() as conn:
        row = conn.execute("SELECT value FROM settings WHERE key=?", (key,)).fetchone()
    return row["value"] if row else default


def set_setting(key: str, value: str) -> None:
    with db() as conn:
        conn.execute(
            "INSERT INTO settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
            (key, value),
        )


def google_client_config() -> dict[str, Any]:
    client_id = os.getenv("GOOGLE_CLIENT_ID", "").strip()
    client_secret = os.getenv("GOOGLE_CLIENT_SECRET", "").strip()
    if not client_id or not client_secret:
        raise RuntimeError("GOOGLE_CLIENT_ID와 GOOGLE_CLIENT_SECRET을 설정해 주세요.")
    return {
        "web": {
            "client_id": client_id,
            "client_secret": client_secret,
            "auth_uri": "https://accounts.google.com/o/oauth2/auth",
            "token_uri": "https://oauth2.googleapis.com/token",
        }
    }


def oauth_redirect_uri() -> str:
    configured = os.getenv("GOOGLE_REDIRECT_URI", "").strip()
    return configured or url_for("google_callback", _external=True, _scheme="https" if request.is_secure else "http")


def load_google_credentials() -> Credentials | None:
    raw = get_setting("google_credentials")
    if not raw:
        return None
    info = json.loads(raw)
    creds = Credentials.from_authorized_user_info(info, scopes=[BLOGGER_SCOPE])
    if creds.expired and creds.refresh_token:
        creds.refresh(GoogleAuthRequest())
        set_setting("google_credentials", creds.to_json())
    return creds


def clean_json_text(text: str) -> str:
    text = text.strip()
    if text.startswith("```"):
        text = text.replace("```json", "", 1).replace("```", "", 1).strip()
    return text


def generate_article(keyword: str, article_type: str, length: str, experience: str) -> dict[str, Any]:
    api_key = os.getenv("OPENAI_API_KEY", "").strip()
    if not api_key:
        return demo_article(keyword, article_type, experience)

    model = os.getenv("OPENAI_TEXT_MODEL", "gpt-4.1-mini")
    prompt = f"""
당신은 한국어 SEO 블로그 편집자입니다. 아래 입력으로 독자에게 실제 도움이 되는 초안을 작성하세요.

키워드: {keyword}
글 유형: {article_type}
목표 분량: 약 {length}자
작성자의 실제 경험/메모: {experience or '없음. 사실로 확인되지 않은 체험을 꾸며내지 말 것.'}

규칙:
- 확인되지 않은 가격, 운영시간, 통계, 효능은 단정하지 마세요.
- 광고성 과장과 키워드 반복을 피하세요.
- 제목 후보는 5개를 만드세요.
- 본문은 HTML로 작성하고 h2, h3, p, ul을 사용하세요.
- 서론, 핵심 내용, 체크리스트, FAQ 3개, 결론을 포함하세요.
- 사용자가 직접 추가 확인해야 할 부분은 '[확인 필요]'라고 표시하세요.
- 반환은 반드시 아래 키만 가진 JSON 객체여야 합니다.

{{
  "titles": ["제목1", "제목2", "제목3", "제목4", "제목5"],
  "meta_description": "120자 안팎 설명",
  "content_html": "HTML 본문",
  "hashtags": ["태그1", "태그2", "태그3"]
}}
"""
    response = requests.post(
        "https://api.openai.com/v1/responses",
        headers={"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"},
        json={"model": model, "input": prompt},
        timeout=120,
    )
    response.raise_for_status()
    payload = response.json()
    text = payload.get("output_text", "")
    if not text:
        chunks = []
        for item in payload.get("output", []):
            for content in item.get("content", []):
                if content.get("type") in {"output_text", "text"}:
                    chunks.append(content.get("text", ""))
        text = "".join(chunks)
    return json.loads(clean_json_text(text))


def demo_article(keyword: str, article_type: str, experience: str) -> dict[str, Any]:
    note = experience or "직접 경험과 최신 정보를 추가해 주세요."
    return {
        "titles": [
            f"{keyword}, 처음 알아볼 때 꼭 확인할 7가지",
            f"{keyword} 실전 가이드: 실패를 줄이는 체크리스트",
            f"{keyword} 한눈에 정리하기",
            f"엄마 관점에서 살펴본 {keyword}",
            f"{keyword} 선택 전 알아두면 좋은 점",
        ],
        "meta_description": f"{keyword}를 찾는 분들을 위해 준비 과정, 확인사항, 실전 팁을 보기 쉽게 정리했습니다.",
        "content_html": f"""
<h2>{keyword}, 무엇부터 확인해야 할까요?</h2>
<p>이 글은 <strong>{article_type}</strong> 초안입니다. 현재 데모 모드라서 실제 정보와 사진을 추가한 뒤 발행해 주세요.</p>
<h2>작성자의 경험 메모</h2><p>{note}</p>
<h2>핵심 체크리스트</h2>
<ul><li>검색하는 사람이 가장 궁금해할 질문을 먼저 답하기</li><li>가격, 시간, 위치는 발행 전에 다시 확인하기</li><li>직접 찍은 사진과 실제 느낌을 추가하기</li></ul>
<h2>자주 묻는 질문</h2>
<h3>정보는 언제 확인해야 하나요?</h3><p>운영시간이나 비용처럼 바뀔 수 있는 정보는 발행 당일 공식 채널에서 확인하는 것이 좋습니다.</p>
<h3>AI 글을 그대로 올려도 되나요?</h3><p>초안으로 활용하고 직접 경험, 사진, 비교 기준을 더하는 편이 좋습니다.</p>
<h3>글은 얼마나 자주 올리나요?</h3><p>처음에는 품질을 유지할 수 있는 범위에서 주 3~5편 정도로 시험해 보세요.</p>
<h2>마무리</h2><p>독자가 글을 읽고 바로 행동할 수 있도록 마지막에 한 줄 체크리스트를 넣어주세요.</p>
""",
        "hashtags": [keyword.replace(" ", ""), "육아정보", "생활정보", "블로그팁"],
    }


def generate_thumbnail(keyword: str, title: str) -> str | None:
    api_key = os.getenv("OPENAI_API_KEY", "").strip()
    if not api_key:
        return None

    model = os.getenv("OPENAI_IMAGE_MODEL", "gpt-image-1")
    prompt = (
        "한국 블로그 썸네일용 깔끔한 가로형 이미지. "
        f"주제는 '{keyword}'. 따뜻하고 밝은 생활정보 매거진 분위기. "
        "사람 얼굴과 상표, 로고, 작은 글자는 넣지 말고 중앙에 제목을 넣을 빈 공간을 확보한다."
    )
    response = requests.post(
        "https://api.openai.com/v1/images/generations",
        headers={"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"},
        json={"model": model, "prompt": prompt, "size": "1536x1024"},
        timeout=180,
    )
    response.raise_for_status()
    data = response.json()["data"][0]
    filename = f"thumb_{datetime.now().strftime('%Y%m%d_%H%M%S_%f')}.png"
    path = THUMB_DIR / filename
    if data.get("b64_json"):
        path.write_bytes(base64.b64decode(data["b64_json"]))
    elif data.get("url"):
        img = requests.get(data["url"], timeout=60)
        img.raise_for_status()
        path.write_bytes(img.content)
    else:
        return None
    return f"thumbnails/{filename}"


def blogger_publish(title: str, content_html: str, as_draft: bool = True) -> dict[str, Any]:
    blog_id = get_setting("blogger_blog_id") or os.getenv("BLOGGER_BLOG_ID", "").strip()
    creds = load_google_credentials()
    token = creds.token if creds else os.getenv("BLOGGER_ACCESS_TOKEN", "").strip()
    if not blog_id or not token:
        raise RuntimeError("먼저 Google 계정을 연결하고 Blogger 블로그를 선택해 주세요.")

    url = f"https://www.googleapis.com/blogger/v3/blogs/{blog_id}/posts/"
    params = {"isDraft": "true" if as_draft else "false"}
    response = requests.post(
        url,
        params=params,
        headers={"Authorization": f"Bearer {token}", "Content-Type": "application/json"},
        json={"kind": "blogger#post", "title": title, "content": content_html},
        timeout=60,
    )
    response.raise_for_status()
    return response.json()


def fetch_blogger_blogs(token: str) -> list[dict[str, Any]]:
    response = requests.get(
        "https://www.googleapis.com/blogger/v3/users/self/blogs",
        headers={"Authorization": f"Bearer {token}"},
        timeout=60,
    )
    response.raise_for_status()
    return response.json().get("items", [])


@app.route("/")
def index():
    with db() as conn:
        articles = conn.execute("SELECT * FROM articles ORDER BY id DESC").fetchall()
    return render_template("index.html", articles=articles, google_connected=bool(get_setting("google_credentials")), blog_name=get_setting("blogger_blog_name"))


@app.post("/generate")
def generate():
    keyword = request.form.get("keyword", "").strip()
    if not keyword:
        flash("키워드를 입력해 주세요.", "error")
        return redirect(url_for("index"))
    article_type = request.form.get("article_type", "정보형")
    length = request.form.get("length", "2500")
    experience = request.form.get("experience", "").strip()
    try:
        article = generate_article(keyword, article_type, length, experience)
        titles = article.get("titles") or [keyword]
        title = titles[0]
        thumb = generate_thumbnail(keyword, title) if request.form.get("make_thumbnail") else None
        now = datetime.now().isoformat(timespec="seconds")
        with db() as conn:
            cur = conn.execute(
                """INSERT INTO articles
                (keyword,title,meta_description,content_html,hashtags,thumbnail_path,status,created_at,updated_at)
                VALUES (?,?,?,?,?,?,?,?,?)""",
                (
                    keyword,
                    title,
                    article.get("meta_description", ""),
                    article.get("content_html", ""),
                    ", ".join(article.get("hashtags", [])),
                    thumb,
                    "saved",
                    now,
                    now,
                ),
            )
            article_id = cur.lastrowid
        return redirect(url_for("edit_article", article_id=article_id))
    except Exception as exc:
        flash(f"생성 중 오류가 발생했습니다: {exc}", "error")
        return redirect(url_for("index"))


@app.route("/article/<int:article_id>", methods=["GET", "POST"])
def edit_article(article_id: int):
    with db() as conn:
        if request.method == "POST":
            conn.execute(
                """UPDATE articles SET title=?, meta_description=?, content_html=?, hashtags=?, updated_at=? WHERE id=?""",
                (
                    request.form.get("title", "").strip(),
                    request.form.get("meta_description", "").strip(),
                    request.form.get("content_html", ""),
                    request.form.get("hashtags", "").strip(),
                    datetime.now().isoformat(timespec="seconds"),
                    article_id,
                ),
            )
            flash("저장했습니다.", "success")
        article = conn.execute("SELECT * FROM articles WHERE id=?", (article_id,)).fetchone()
    if article is None:
        return "글을 찾을 수 없습니다.", 404
    return render_template("edit.html", article=article, preview=Markup(article["content_html"]))


@app.post("/article/<int:article_id>/publish")
def publish(article_id: int):
    as_draft = request.form.get("mode", "draft") == "draft"
    with db() as conn:
        article = conn.execute("SELECT * FROM articles WHERE id=?", (article_id,)).fetchone()
        if article is None:
            return "글을 찾을 수 없습니다.", 404
        try:
            result = blogger_publish(article["title"], article["content_html"], as_draft=as_draft)
            status = "blogger_draft" if as_draft else "published"
            conn.execute(
                "UPDATE articles SET status=?, blogger_post_id=?, updated_at=? WHERE id=?",
                (status, result.get("id"), datetime.now().isoformat(timespec="seconds"), article_id),
            )
            flash("Blogger에 임시저장했습니다." if as_draft else "Blogger에 발행했습니다.", "success")
        except Exception as exc:
            flash(f"Blogger 전송 실패: {exc}", "error")
    return redirect(url_for("edit_article", article_id=article_id))


@app.get("/google/connect")
def google_connect():
    try:
        flow = Flow.from_client_config(google_client_config(), scopes=[BLOGGER_SCOPE])
        flow.redirect_uri = oauth_redirect_uri()
        authorization_url, state = flow.authorization_url(
            access_type="offline",
            include_granted_scopes="true",
            prompt="consent",
        )
        session["oauth_state"] = state
        return redirect(authorization_url)
    except Exception as exc:
        flash(f"Google 연결 준비 실패: {exc}", "error")
        return redirect(url_for("index"))


@app.get("/google/callback")
def google_callback():
    try:
        flow = Flow.from_client_config(google_client_config(), scopes=[BLOGGER_SCOPE], state=session.get("oauth_state"))
        flow.redirect_uri = oauth_redirect_uri()
        flow.fetch_token(authorization_response=request.url)
        creds = flow.credentials
        set_setting("google_credentials", creds.to_json())
        blogs = fetch_blogger_blogs(creds.token)
        if not blogs:
            raise RuntimeError("연결된 Blogger 블로그가 없습니다. Blogger에서 블로그를 먼저 만들어 주세요.")
        selected = blogs[0]
        set_setting("blogger_blog_id", str(selected["id"]))
        set_setting("blogger_blog_name", selected.get("name", "Blogger"))
        flash(f"Google 연결 완료: {selected.get('name', 'Blogger')}", "success")
    except Exception as exc:
        flash(f"Google 연결 실패: {exc}", "error")
    return redirect(url_for("index"))


@app.post("/google/disconnect")
def google_disconnect():
    for key in ("google_credentials", "blogger_blog_id", "blogger_blog_name"):
        with db() as conn:
            conn.execute("DELETE FROM settings WHERE key=?", (key,))
    flash("Google 연결을 해제했습니다.", "success")
    return redirect(url_for("index"))


@app.post("/article/<int:article_id>/delete")
def delete_article(article_id: int):
    with db() as conn:
        article = conn.execute("SELECT thumbnail_path FROM articles WHERE id=?", (article_id,)).fetchone()
        conn.execute("DELETE FROM articles WHERE id=?", (article_id,))
    if article and article["thumbnail_path"]:
        path = DATA_DIR / article["thumbnail_path"]
        if path.exists():
            path.unlink()
    flash("삭제했습니다.", "success")
    return redirect(url_for("index"))


@app.route("/media/<path:filename>")
def media(filename: str):
    return send_from_directory(DATA_DIR, filename)


init_db()

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.getenv("PORT", "5000")), debug=True)
